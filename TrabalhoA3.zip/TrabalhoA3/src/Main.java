public class Main {
    public static void main(String[] args) {

        Menu menu = new Menu();
        menu.exibirMenu();

    
        Marca marca = new Marca("Golf");
        Modelo modelo = new Modelo("GTI", marca);

        
        Carro carro = new Carro("ABC-1234", modelo);

       
        Cliente cliente = new Cliente("12345678900", "Carlos Sainz", "Rua Madrid, 100", "5510-0000");

        
        Reserva reserva = new Reserva(cliente, carro);

        
        System.out.println("Cliente: " + cliente.getNome());
        System.out.println("Carro reservado: " + carro.getModelo().getNome() + " - " + carro.getPlaca());
        System.out.println("Marca: " + carro.getModelo().getMarca().getNome());
        System.out.println("Situação do carro: " + carro.getSituacao());
        System.out.println("Data da reserva: " + reserva.getDataReserva());
    }
}
    


