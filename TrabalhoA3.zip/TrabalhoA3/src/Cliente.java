import java.util.Scanner;
import java.util.regex.Pattern;

public class Cliente {

    private String cpf;
    private String nome;
    private String endereco;
    private String telefone;

    public Cliente(String cpf, String nome, String endereco, String telefone) {
        this.cpf = cpf;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    public String getCpf() { return cpf; }
    public String getNome() { return nome; }
    public String getEndereco() { return endereco; }
    public String getTelefone() { return telefone; }

    public void setCpf(String cpf) { this.cpf = cpf; }
    public void setNome(String nome) { this.nome = nome; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    // Scanner e métodos corretamente posicionados
    Scanner scanner = new Scanner(System.in);

    private boolean validarCPF(String cpf) {
        return cpf.matches("\\d{11}");
    }

    private void cadastrarCliente() {
        System.out.print("CPF do cliente (somente números): ");
        String cpf = scanner.nextLine();

        if (!validarCPF(cpf)) {
            System.out.println("CPF inválido! Tente novamente.");
            return;
        }

        System.out.println("CPF válido! Cadastro realizado.");
    }
}


