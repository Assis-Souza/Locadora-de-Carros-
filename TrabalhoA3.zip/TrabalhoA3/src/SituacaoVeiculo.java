public enum SituacaoVeiculo 
{
    DISPONIVEL,
    ALUGADO,
    MANUTENCAO
}