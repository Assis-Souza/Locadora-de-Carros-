import java.time.LocalDate;
public class Reserva 
{
    private Cliente cliente;
    private Carro carro;
    private LocalDate dataReserva;

    public Reserva(Cliente cliente, Carro carro) {
        this.cliente = cliente;
        this.carro = carro;
        this.dataReserva = LocalDate.now();
        carro.setSituacao(SituacaoVeiculo.ALUGADO);
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Carro getCarro() {
        return carro;
    }

    public LocalDate getDataReserva() {
        return dataReserva;
    }
}
