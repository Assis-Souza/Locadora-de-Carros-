    import java.util.ArrayList;
    import java.util.List;
    import java.util.regex.Pattern;
    public class Locadora {
    private String cpfOuCnpj;
    private String fabricante;
    private String endereco;
    private List<Carro> carros = new ArrayList<>();

    
    public Locadora(String cpfOuCnpj, String fabricante, String endereco) {
        setCpfOuCnpj(cpfOuCnpj);
        this.fabricante = fabricante;
        this.endereco = endereco;
    }

    
    private boolean isValidCpfCnpj(String valor) {
        String cpfPattern = "\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}";
        String cnpjPattern = "\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}-\\d{2}";
        return Pattern.matches(cpfPattern, valor) || Pattern.matches(cnpjPattern, valor);
    }

    
    public String getCpfOuCnpj() {
        return cpfOuCnpj;
    }

    public void setCpfOuCnpj(String cpfOuCnpj) {
        if (isValidCpfCnpj(cpfOuCnpj)) {
            this.cpfOuCnpj = cpfOuCnpj;
        } else {
            throw new IllegalArgumentException("CPF ou CNPJ inválido!");
        }
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Carro buscarCarro(String placa) {
        for (Carro carro : carros) {
            if (carro.getPlaca().equalsIgnoreCase(placa)) {
                return carro;
            }
        }
        return null;
    }
    
    public void adicionarCarro(Carro carro) {
        carros.add(carro);
    }

    public boolean excluirCarro(String placa) {
        Carro carro = buscarCarro(placa);
        if (carro != null) {
            carros.remove(carro);
            return true;
        }
        return false;
    }

    public void listarCarros() {
        if (carros.isEmpty()) {
            System.out.println("Nenhum carro cadastrado.");
        } else {
            for (Carro carro : carros) {
                System.out.println(carro.getModelo().getNome() + " - " + carro.getPlaca());
            }
        }
    }
   
    }