import java.util.Scanner;

public class Menu {
    private Locadora locadora = new Locadora("123.456.789-00", "Locadora Williams", "Rua Madrid, 100");
    private Scanner scanner = new Scanner(System.in);

    public void exibirMenu() {
        int opcao = 0;

        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Cadastrar Carro");
            System.out.println("2. Listar Carros");
            System.out.println("3. Buscar Carro");
            System.out.println("4. Excluir Carro");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();
            scanner.nextLine(); // consumir quebra de linha

            switch (opcao) {
                case 1 -> cadastrarCarro();
                case 2 -> locadora.listarCarros();
                case 3 -> buscarCarro();
                case 4 -> excluirCarro();
                case 5 -> System.out.println("Encerrando...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 5);
    }

    private void cadastrarCarro() {
        System.out.print("Placa: ");
        String placa = scanner.nextLine();

        System.out.print("Modelo: ");
        String nomeModelo = scanner.nextLine();

        System.out.print("Marca: ");
        String nomeMarca = scanner.nextLine();

        Marca marca = new Marca(nomeMarca);
        Modelo modelo = new Modelo(nomeModelo, marca);
        Carro carro = new Carro(placa, modelo);

        locadora.adicionarCarro(carro);
        System.out.println("Carro adicionado!");
    }

    private void buscarCarro() {
        System.out.print("Digite a placa: ");
        String placa = scanner.nextLine();
        Carro carro = locadora.buscarCarro(placa);
        if (carro != null) {
            System.out.println("Encontrado: " + carro.getModelo().getNome() + " - " + carro.getPlaca());
        } else {
            System.out.println("Carro não encontrado.");
        }
    }

    private void excluirCarro() {
        System.out.print("Placa do carro a excluir: ");
        String placa = scanner.nextLine();
        if (locadora.excluirCarro(placa)) {
            System.out.println("Carro excluído.");
        } else {
            System.out.println("Carro não encontrado.");
        }
    }
}
