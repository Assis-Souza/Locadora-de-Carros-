import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

enum SituacaoVeiculo {
    DISPONIVEL, ALUGADO, MANUTENCAO
}

public class Carro {
    private String placa;
    private SituacaoVeiculo situacao;
    private Modelo modelo;

    public Carro(String placa, Modelo modelo) {
        this.placa = placa;
        this.modelo = modelo;
        this.situacao = SituacaoVeiculo.DISPONIVEL;
    }

    public String getPlaca() {
        return placa;
    }

    public Modelo getModelo() {
        return modelo;
    }

    public SituacaoVeiculo getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoVeiculo situacao) {
        this.situacao = situacao;
    }
}

class CarroCRUD {
    private List<Carro> carros = new ArrayList<>();

    public void adicionar(Carro carro) {
        carros.add(carro);
    }

    public List<Carro> listar() {
        return new ArrayList<>(carros);
    }

    public Optional<Carro> buscarPorPlaca(String placa) {
        return carros.stream()
            .filter(c -> c.getPlaca().equalsIgnoreCase(placa))
            .findFirst();
    }

    public boolean atualizarSituacao(String placa, SituacaoVeiculo novaSituacao) {
        Optional<Carro> carro = buscarPorPlaca(placa);
        if (carro.isPresent()) {
            carro.get().setSituacao(novaSituacao);
            return true;
        }
        return false;
    }

    public boolean remover(String placa) {
        return carros.removeIf(c -> c.getPlaca().equalsIgnoreCase(placa));
    }
}
